﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Utf8Json")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("929e3779-4c3a-42a3-bc72-3d77511e988f")]
[assembly: AssemblyVersion("1.3.7")]
[assembly: AssemblyFileVersion("1.3.7")]
