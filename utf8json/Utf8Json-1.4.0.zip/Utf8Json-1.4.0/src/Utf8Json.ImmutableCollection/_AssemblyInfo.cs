﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Utf8Json.ImmutableCollection")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("2e7ac239-3db1-4772-9f47-5f62abb56ed0")]
[assembly: AssemblyVersion("1.3.7")]
[assembly: AssemblyFileVersion("1.3.7")]