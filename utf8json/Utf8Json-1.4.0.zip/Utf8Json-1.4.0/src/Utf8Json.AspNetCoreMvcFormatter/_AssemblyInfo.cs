﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Utf8Json.AspNetCoreMvcFormatter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("899f8b6c-c4c7-4e8b-9875-f61fdfb630bd")]
[assembly: AssemblyVersion("1.3.7")]
[assembly: AssemblyFileVersion("1.3.7")]