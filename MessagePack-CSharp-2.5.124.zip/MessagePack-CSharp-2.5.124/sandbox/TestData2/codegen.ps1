dotnet run -f "net7.0" --project "$PSScriptRoot/../../src/MessagePack.Generator/MessagePack.Generator.csproj" -- -i "$PSScriptRoot/TestData2.csproj" -o "$PSScriptRoot/Generated.cs"
