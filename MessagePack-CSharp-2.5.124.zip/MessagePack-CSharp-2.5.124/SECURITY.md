# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| <= 1.7  | :x:                |
| 1.8.x   | :white_check_mark: |
| 2.0.x   | :white_check_mark: |

## Reporting a Vulnerability

Please use email to contact the project's main contributors with any vulnerability you become aware of.

    Yoshifumi Kawai <ils@neue.cc>; Andrew Arnott <andrewarnott@gmail.com>
