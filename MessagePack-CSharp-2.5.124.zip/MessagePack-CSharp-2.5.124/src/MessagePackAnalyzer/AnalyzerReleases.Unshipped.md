﻿; Unshipped analyzer release
; https://github.com/dotnet/roslyn-analyzers/blob/main/src/Microsoft.CodeAnalysis.Analyzers/ReleaseTrackingAnalyzers.Help.md

### New Rules

Rule ID | Category | Severity | Notes
--------|----------|----------|-------
MsgPack001 | Reliability | Disabled | MsgPack001SpecifyOptionsAnalyzer
MsgPack002 | Reliability | Disabled | MsgPack002UseConstantOptionsAnalyzer
MsgPack003 | Usage | Error | MessagePackAnalyzer
MsgPack004 | Usage | Error | MessagePackAnalyzer
MsgPack005 | Usage | Error | MessagePackAnalyzer
MsgPack006 | Usage | Error | MessagePackAnalyzer