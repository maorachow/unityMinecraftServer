# MessagePack.Experimental

This C# project is the experimental project for the features which are very complex, unstable or unsafe.

- [HardwareIntrinsics](HardwareIntrinsics/HardwareIntrinsics.md)
- [UnsafeUnmanagedStructFormatter](UnsafeUnmanagedStructFormatter/UnsafeUnmanagedStructFormatter.md)

**Caution!**

`MessagePack.Experimental` only targets `.NET Core 3.1` and above.
You can not use this in Unity and .NET Framework.