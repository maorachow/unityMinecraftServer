﻿// Copyright (c) All contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#if UNITY_2018_3_OR_NEWER

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("MessagePack.Tests")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Assembly-CSharp")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Assembly-CSharp-Editor")]

#endif
