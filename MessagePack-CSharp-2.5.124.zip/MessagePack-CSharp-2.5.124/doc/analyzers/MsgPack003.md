# MsgPack003 Use MessagePackObjectAttribute

Type must be marked with `MessagePackObjectAttribute`.
