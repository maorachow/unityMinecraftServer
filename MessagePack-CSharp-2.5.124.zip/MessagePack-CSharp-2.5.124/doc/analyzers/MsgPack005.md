# MsgPack005 MessagePackObject validation

Invalid MessagePackObject definition.
