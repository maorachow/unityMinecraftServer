# MsgPack004 Attribute public members of MessagePack objects

Public members of `MessagePackObjectAttribute`-attributed types require either `KeyAttribute` or `IgnoreMemberAttribute`.
